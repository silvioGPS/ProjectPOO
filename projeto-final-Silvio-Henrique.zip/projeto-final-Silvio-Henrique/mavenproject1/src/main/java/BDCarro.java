//Silvio Henrique Mendes dos Santos RA: a2618095

import java.util.List;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class BDCarro {

    private Carro c;
    
    private List<Carro> bdCar;
    static BDCarro gCarroUnico;
    
    private BDCarro(){
        c = new Carro();
        bdCar = new ArrayList<Carro>();
    }

    public static BDCarro gCarroUnico() { //Método Singleton
        if (gCarroUnico == null) {
            gCarroUnico = new BDCarro();
        }
        return gCarroUnico;
    }

    public List<Carro> getBdCar() {
        return bdCar;
    }

    public Carro cadCarro(Carro c) {
        if (consCarroPlaca(c) == null) {
            bdCar.add(c);
            return c;
        } else {
            return null;
        }
    }// fim do cadVei

    public Carro consCarroPlaca(Carro c) {
        for (int i = 0; i < bdCar.size(); i++) {
            if (c.getPlaca().equals(bdCar.get(i).getPlaca())) {
                //JOptionPane.showMessageDialog(null, "Confirme os dados inseridos");
                return bdCar.get(i);

            }
        }
        return null;
    }//fim consVeiPlaca	

    public Carro removeCarPlaca(Carro c) {
        c = consCarroPlaca(c);
        if (c != null) {
            bdCar.remove(c);
            return null;
        } else {
            return c;
        }
    }//fim removeVeiPlaca

    public Carro atualizaCarroPlaca(Carro c) { //Não atualiza a Placa, apenas os demais campos
        for (int i = 0; i < bdCar.size(); i++) {
            if (c.getPlaca().equals(bdCar.get(i).getPlaca())) {

                try {
                    String marca = JOptionPane.showInputDialog(
                            null,
                            "Informe a NOVA marca: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    c.setMarca(marca);
                    bdCar.set(i, c);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO tipo: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    c.setTipoVeiculo(r);
                    bdCar.set(i, c);
                } catch (NullPointerException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente letras", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVo tipo de combustível: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    c.setTipoCombustivel(r);
                    bdCar.set(i, c);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe a NOVA capacidade do Tanque: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    c.setCapacTanque(Integer.parseInt(r));
                    bdCar.set(i, c);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO Km atual: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    c.setKmAtual(Integer.parseInt(r));
                    bdCar.set(i, c);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO Km da Ultima troca de óleo: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    c.setKmUltimaTroc(Integer.parseInt(r));
                    bdCar.set(i, c);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO tipo de óleo do veículo: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    c.setTipoOleo(r);
                    bdCar.set(i, c);
                    // return bdCar.get(i);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe a NOVA quantidade de cavalos: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    c.setQtdCvs(r);
                    bdCar.set(i, c);
                    return bdCar.get(i);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

            }
        }
        return null;
    }//fim atualizaVeiPlaca

}//fim da classe
