//Nome: Silvio Henrique Mendes dos Santos RA:a2618095

import javax.swing.JOptionPane;

public class PlacaException extends Exception {

    public void impPlacaException() {
        JOptionPane.showMessageDialog(null, "Informe um formato valido de placa, contendo 3 letras maiusculas e 4 numeros. Exemplo: AAA0001", "Erro", 0);
    }
}
