//Nome: Silvio Henrique Mendes dos Santos RA:a2618095

import javax.swing.JOptionPane;

public class Funcionario {

    private String nome;
    private int idFunc;
    private float valHora;
    private int horasTrab;

    public Funcionario() {
        super();
        nome = "";
        idFunc = 0;
        valHora = 0;
        horasTrab = 0;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) throws LetException {
        if (nome.matches("[a-zA-z]+")) {
            this.nome = nome;
        } else {
            throw new LetException();
        }
    }

    public int getIdFunc() {
        return idFunc;
    }

    public void setIdFunc(int idFunc) {
        this.idFunc = idFunc;
    }

    public float getValHora() {
        return valHora;
    }

    public void setValHora(float valHora) {
        this.valHora = valHora;
    }

    public int getHorasTrab() {
        return horasTrab;
    }

    public void setHorasTrab(int horasTrab) {
        this.horasTrab = horasTrab;
    }

    //Polimorfismo por Sobrecarga
    public double calcularSalario(int horasTrab, double valHora) {
        double r;
        r = horasTrab * valHora;
        String vFormat = String.format("R$ %.2f", r);
        JOptionPane.showMessageDialog(null, "Valor do Salário sem bônus: " + vFormat, " Total", 1);
        return r;
    }

    //Polimorfismo por Sobrecarga
    public double calcularSalario(double bonus) {
        double r;
        r = bonus + calcularSalario(getHorasTrab(), getValHora());
        String vFormat = String.format("R$ %.2f", r);
        JOptionPane.showMessageDialog(null, "Valor do Salário com bônus: " + vFormat, " Total", 1);
        return bonus;
    }
}
