//Nome: Silvio Henrique Mendes dos Santos RA:a2618095

import javax.swing.JOptionPane;

public class Carro extends Veiculo {

    private String qtdCv;
    private String tipoVeiculo;

    public Carro() {
        super();
        qtdCv = "";
        tipoVeiculo = "";
    }

    public String getQtdCv() {
        return qtdCv;
    }

    public void setQtdCvs(String qtdCv) {
        this.qtdCv = qtdCv;
    }

    @Override
    public String getTipoVeiculo() {
        return tipoVeiculo;
    }

    @Override
    public void setTipoVeiculo(String tipoVeiculo) {
        this.tipoVeiculo = tipoVeiculo;
    }

    //Polimorfismo por Sobrescrita
    public void cadastrar() {
        System.out.println("Carro cadastrado\n");
    }

    //Polimorfismo por Sobrescrita
    public void abastecer() {

        if (getTipoCombustivel().equalsIgnoreCase("Gasolina")) {
            double r1 = getQtdLitrosComb() * 6.30;
            String vFormat = String.format("R$ %.2f", r1);
            JOptionPane.showMessageDialog(null, "Valor do abastecimento: " + vFormat, " Total", 1);
        } else if (getTipoCombustivel().equalsIgnoreCase("Etanol")) {
            double r1 = getQtdLitrosComb() * 4.31;
            String vFormat = String.format("R$ %.2f", r1);
            JOptionPane.showMessageDialog(null, "Valor do abastecimento: " + vFormat, "Total", 1);
        } else if (getTipoCombustivel().equalsIgnoreCase("Diesel")) {
            double r1 = getQtdLitrosComb() * 6.05;
            String vFormat = String.format("R$ %.2f", r1);
            JOptionPane.showMessageDialog(null, "Valor do abastecimento: " + vFormat, "Total", 1);
        } else {
            JOptionPane.showMessageDialog(null, "Nao foi possivel encontrar nenhum combustivel ou nenhuma carro foi cadastrado.", "Erro", 0);

        }

        /*
    //Metodo da Interface
    public void calcProxTrocOleo(){ 
        if(getKmAtual() > getKmUltimaTroc()){
            double diferenca = getKmAtual() - getKmUltimaTroc();
            if (diferenca > 10000) {
                System.out.println("O oleo do seu veiculo precisa ser trocado.\n");
            } else{
                System.out.println("O oleo de seu veiculo ainda nao precisa ser trocado\n");
            }
        }
    }*/
    }
}
