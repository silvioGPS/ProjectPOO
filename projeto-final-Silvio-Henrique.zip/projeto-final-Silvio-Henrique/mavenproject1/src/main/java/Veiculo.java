//Nome: Silvio Henrique Mendes dos Santos RA:a2618095

public class Veiculo {

    //Reflexividade
    Funcionario f = new Funcionario();

    private String marca;
    private String tipoVeiculo;
    private String tipoCombustivel;
    private int capacTanque;
    private int kmAtual;
    private int kmUltimaTroc;
    private int qtdLitrosComb;
    private String tipoOleo;
    private String placa;

    public Veiculo() {
        marca = "";
        tipoVeiculo = "";
        tipoCombustivel = "";
        capacTanque = 0;
        kmAtual = 0;
        kmUltimaTroc = 0;
        qtdLitrosComb = 0;
        tipoOleo = "";
        placa = "";
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) throws LetException, NumberFormatException {
        if (marca.matches("[a-zA-z]+")) {
            this.marca = marca;
        } else {
            throw new LetException();
        }
    }

    public String getTipoVeiculo() {
        return tipoVeiculo;
    }

    public void setTipoVeiculo(String tipoVeiculo) throws LetException, NumberFormatException {
        if (tipoVeiculo.matches("[a-zA-z]+")) {
            this.tipoVeiculo = tipoVeiculo;
        } else {
            throw new LetException();
        }
    }

    public String getTipoCombustivel() {
        return tipoCombustivel;
    }

    public void setTipoCombustivel(String tipoCombustivel) throws LetException {
        if (tipoCombustivel.matches("[a-zA-z]+")) {
            this.tipoCombustivel = tipoCombustivel;
        } else {
            throw new LetException();
        }

    }

    public int getCapacTanque() {
        return capacTanque;
    }

    public void setCapacTanque(int capacTanque) {
        this.capacTanque = capacTanque;
    }

    public int getKmAtual() {
        return kmAtual;
    }

    public void setKmAtual(int kmAtual) {
        this.kmAtual = kmAtual;
    }

    public int getKmUltimaTroc() {
        return kmUltimaTroc;
    }

    public void setKmUltimaTroc(int kmUltimaTroc) {
        this.kmUltimaTroc = kmUltimaTroc;
    }

    public int getQtdLitrosComb() {
        return qtdLitrosComb;
    }

    public void setQtdLitrosComb(int qtdLitrosComb) throws GasolException {
        if (qtdLitrosComb > getCapacTanque()) {
            throw new GasolException();
        } else {
            this.qtdLitrosComb = qtdLitrosComb;
        }

    }

    public String getTipoOleo() {
        return tipoOleo;
    }

    public void setTipoOleo(String tipoOleo) throws LetException, NumberFormatException {
        if (tipoOleo.matches("[a-zA-Z]+")) {
            this.tipoOleo = tipoOleo;
        } else {
            throw new LetException();
        }
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) throws PlacaException, StringIndexOutOfBoundsException {
        if (placa.length() == 7) {
            if (placa.substring(0, 3).matches("[A-Z]*") && placa.substring(3).matches("[0-9]*")) {
                this.placa = placa;
            } else {
                throw new PlacaException();
            }
        } else {
            throw new StringIndexOutOfBoundsException();
        }

    }

    public void abastecer() {
    }

    ;

    public void cadastrar() {
    }
;

}
