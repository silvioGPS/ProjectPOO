//Silvio Henrique Mendes dos Santos RA: a2618095

import java.util.List;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class BDCaminhao {

    private Caminhao cam;
    private List<Caminhao> bdCam;
    static BDCaminhao gCaminhaoUnico;
    
    private BDCaminhao(){
        cam = new Caminhao();
        bdCam = new ArrayList<Caminhao>();
    }

    public static BDCaminhao gCaminhaoUnico() { //Método Singleton
        if (gCaminhaoUnico == null) {
            gCaminhaoUnico = new BDCaminhao();
        }
        return gCaminhaoUnico;
    }

    public List<Caminhao> getBdCam() {
        return bdCam;
    }

    public Caminhao cadCaminhao(Caminhao cam) {
        if (consCamPlaca(cam) == null) {
            bdCam.add(cam);
            return cam;
        } else {
            return null;
        }
    }// fim do cadVei

    public Caminhao consCamPlaca(Caminhao cam) {
        for (int i = 0; i < bdCam.size(); i++) {
            if (cam.getPlaca().equals(bdCam.get(i).getPlaca())) {
                return bdCam.get(i);

            }
        }
        return null;
    }//fim consCamPlaca	

    public Veiculo removeCamPlaca(Caminhao cam) {
        cam = consCamPlaca(cam);
        if (cam != null) {
            bdCam.remove(cam);
            return null;
        } else {
            return cam;
        }
    }//fim removeCamPlaca

    public Caminhao atualizaCamPlaca(Caminhao cam) { //Não atualiza a Placa, apenas os demais campos
        for (int i = 0; i < bdCam.size(); i++) {
            if (cam.getPlaca().equals(bdCam.get(i).getPlaca())) {

                try {
                    String marca = JOptionPane.showInputDialog(
                            null,
                            "Informe a NOVA marca: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    cam.setMarca(marca);
                    bdCam.set(i, cam);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVo tipo do veículo: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    cam.setTipoVeiculo(r);
                    bdCam.set(i, cam);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVo tipo de combustível: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    cam.setTipoCombustivel(r);
                    bdCam.set(i, cam);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe a NOVA capacidade do Tanque: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    cam.setCapacTanque(Integer.parseInt(r));
                    bdCam.set(i, cam);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO Km atual: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    cam.setKmAtual(Integer.parseInt(r));
                    bdCam.set(i, cam);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO Km da Ultima troca de óleo: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    cam.setKmUltimaTroc(Integer.parseInt(r));
                    bdCam.set(i, cam);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO tipo de óleo: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    cam.setTipoOleo(r);
                    bdCam.set(i, cam);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO tipo de carga: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    cam.setTipoCarga(r);
                    bdCam.set(i, cam);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO tipo de Injeção: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    cam.setTipoInjecao(r);
                    bdCam.set(i, cam);
                    return bdCam.get(i);
                } catch (LetException lep) {
                    lep.impLetException();
                } catch (NullPointerException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

            }
        }
        return null;
    }//fim atualizaCamPlaca
}//fim da classe
