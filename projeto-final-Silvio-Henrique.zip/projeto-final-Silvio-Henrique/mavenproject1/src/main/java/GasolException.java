
//Nome: Silvio Henrique Mendes dos Santos RA:a2618095
import javax.swing.JOptionPane;

public class GasolException extends Exception {

    public void impGasolExecption() {
        JOptionPane.showMessageDialog(null, "A quantidade de gasolina informada ultrapassa o limite do tanque", "Erro", 0);
    }
}
