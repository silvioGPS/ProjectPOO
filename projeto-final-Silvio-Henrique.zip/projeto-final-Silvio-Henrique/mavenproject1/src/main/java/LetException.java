//Nome: Silvio Henrique Mendes dos Santos RA:a2618095

import javax.swing.JOptionPane;

//Nome: Silvio Henrique Mendes dos Santos RA:a2618095
public class LetException extends Exception {

    public void impLetException() {
        JOptionPane.showMessageDialog(null, "Informe apenas caracteres, esses caracteres devem ser minúsculos", "Erro", 0);

    }

}
