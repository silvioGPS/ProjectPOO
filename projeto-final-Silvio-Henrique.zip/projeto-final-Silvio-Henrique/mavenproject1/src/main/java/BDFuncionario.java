//Silvio Henrique Mendes dos Santos RA: a2618095

import java.util.List;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class BDFuncionario {

    private Funcionario fun;
    private List<Funcionario> bdFun;
    static BDFuncionario gFuncUnico;
    
    private BDFuncionario(){
        fun = new Funcionario();
        bdFun = new ArrayList<Funcionario>();
    }

    public static BDFuncionario gFuncUnico() { //Método Singleton
        if (gFuncUnico == null) {
            gFuncUnico = new BDFuncionario();
        }
        return gFuncUnico;
    }

    public List<Funcionario> getBdFun() {
        return bdFun;
    }

    public Funcionario cadFuncionario(Funcionario fun) {
        if (consFunId(fun) == null) {
            bdFun.add(fun);
            return fun;
        } else {
            return null;
        }
    }// fim do cadVei

    public Funcionario consFunId(Funcionario fun) {
        for (int i = 0; i < bdFun.size(); i++) {
            if (fun.getIdFunc() == bdFun.get(i).getIdFunc()) {
                //JOptionPane.showMessageDialog(null, "Confirme os dados inseridos");
                return bdFun.get(i);

            }
        }
        return null;
    }//fim consVeiPlaca	

    public Funcionario removeFuncId(Funcionario fun) {
        fun = consFunId(fun);
        if (fun != null) {
            bdFun.remove(fun);
            return null;
        } else {
            return fun;
        }
    }//fim removeVeiPlaca

    public Funcionario atualizaFuncId(Funcionario fun) { //Não atualiza o ID, apenas os demais campos
        for (int i = 0; i < bdFun.size(); i++) {
            if (fun.getIdFunc() == bdFun.get(i).getIdFunc()) {

                try {
                    String nome = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO nome: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    fun.setNome(nome);
                    bdFun.set(i, fun);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO valor da hora: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    fun.setValHora(Float.parseFloat(r));
                    bdFun.set(i, fun);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe a NOVA quantidade de horas trabalhadas : ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    fun.setHorasTrab(Integer.parseInt(r));
                    bdFun.set(i, fun);
                    return bdFun.get(i);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }
            }
        }
        return null;
    }//fim atualizaVeiPlaca
}//fim da classe
