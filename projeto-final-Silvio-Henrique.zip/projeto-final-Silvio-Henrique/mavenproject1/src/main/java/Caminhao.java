//Nome: Silvio Henrique Mendes dos Santos RA:a2618095

import javax.swing.JOptionPane;


public class Caminhao extends Veiculo{
    private String tipoCarga;
    private String injecao;
    

    public Caminhao(){
        super();
        tipoCarga = "";
        injecao = "";
    }

    public String getTipoCarga(){
        return tipoCarga;
    }

    public void setTipoCarga(String tipoCarga) throws LetException{
        if (tipoCarga.matches("[a-zA-z]+")) {
            this.tipoCarga = tipoCarga;
        } else {
            throw new LetException();
        }
    }

    public String getTipoInjecao(){
        return injecao;
    }

    public void setTipoInjecao(String injecao) throws LetException {
        if (injecao.matches("[a-zA-z]+")) {
            this.injecao = injecao;
        } else {
            throw new LetException();
        }
    }

    /*// Polimorfismo por Sobrescrita
    @Override
    public void cadastrar(){ 
        System.out.println("Caminhao cadastrado \n");
    }
*/
    // Polimorfismo por Sobrescrita
    public void abastecer(){ 
        if(getTipoCombustivel().equalsIgnoreCase("Diesel")){
            double r1 = getQtdLitrosComb() * 6.05;
            String vFormat = String.format("R$ %.2f", r1);
            JOptionPane.showMessageDialog(null, "Valor do abastecimento: " + vFormat, " Total", 1);
        }else if(getTipoCombustivel().equalsIgnoreCase("Gasolina")) {
           double r1 = getQtdLitrosComb() * 6.30;
           String vFormat = String.format("R$ %.2f", r1);
            JOptionPane.showMessageDialog(null, "Valor do abastecimento: " + vFormat, " Total", 1);
        }else if(getTipoCombustivel().equalsIgnoreCase("Etanol")){
           double r1 = getQtdLitrosComb() * 4.31;
            String vFormat = String.format("R$ %.2f", r1);
            JOptionPane.showMessageDialog(null, "Valor do abastecimento: " + vFormat, " Total", 1);
        }else{
            JOptionPane.showMessageDialog(null, "Nao foi possivel encontrar nenhum combustivel ou nenhuma caminhao foi cadastrado.", "Erro", 0);
        }
    }


}
