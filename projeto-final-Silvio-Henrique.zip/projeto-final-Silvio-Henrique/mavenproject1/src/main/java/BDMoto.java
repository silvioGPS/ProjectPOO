
//Silvio Henrique Mendes dos Santos RA: a2618095
import java.util.List;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class BDMoto {

    private Moto mot;
    private List<Moto> bdMot;
    static BDMoto gMotUnico;
    
    private BDMoto(){
        mot = new Moto();
        bdMot = new ArrayList<Moto>();
    }

    public static BDMoto gMotUnico() { //Método Singleton
        if (gMotUnico == null) {
            gMotUnico = new BDMoto();
        }
        return gMotUnico;
    }

    public List<Moto> getBdMot() {
        return bdMot;
    }

    public Moto cadMoto(Moto mot) {
        if (consMotoPlaca(mot) == null) {
            bdMot.add(mot);
            return mot;
        } else {
            return null;
        }
    }// fim do cadMoto

    public Moto consMotoPlaca(Moto mot) {
        for (int i = 0; i < bdMot.size(); i++) {
            if (mot.getPlaca().equals(bdMot.get(i).getPlaca())) {
                return bdMot.get(i);
            }
        }
        return null;
    }//fim consMotoPlaca	

    public Moto removeMotoPlaca(Moto mot) {
        mot = consMotoPlaca(mot);
        if (mot != null) {
            bdMot.remove(mot);
            return null;
        } else {
            return mot;
        }
    }//fim removeMotoPlaca

    public Moto atualizaMotoPlaca(Moto mot) { //Não atualiza a Placa, apenas os demais campos
        for (int i = 0; i < bdMot.size(); i++) {
            if (mot.getPlaca().equals(bdMot.get(i).getPlaca())) {

                try {
                    String marca = JOptionPane.showInputDialog(
                            null,
                            "Informe a NOVA marca: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    mot.setMarca(marca);
                    bdMot.set(i, this.mot);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVo tipo do veículo: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    mot.setTipoVeiculo(r);
                    bdMot.set(i, mot);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVo tipo de combustível: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    mot.setTipoCombustivel(r);
                    bdMot.set(i, mot);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe a NOVA capacidade do Tanque: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    mot.setCapacTanque(Integer.parseInt(r));
                    bdMot.set(i, mot);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO Km atual: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    mot.setKmAtual(Integer.parseInt(r));
                    bdMot.set(i, mot);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO Km da Ultima troca de óleo: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    mot.setKmUltimaTroc(Integer.parseInt(r));
                    bdMot.set(i, mot);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO tipo de óleo do veículo: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    mot.setTipoOleo(r);
                    bdMot.set(i, mot);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe o NOVO tipo de carburador: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    mot.setCarburador(r);
                    bdMot.set(i, mot);
                } catch (LetException lep) {
                    lep.impLetException();
                }

                try {
                    String r = JOptionPane.showInputDialog(
                            null,
                            "Informe a NOVA cilindrada: ",
                            "Atualizar dados",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                    mot.setCilindrada(r);
                    bdMot.set(i, mot);
                    return bdMot.get(i);
                } catch (NumberFormatException nep) {
                    JOptionPane.showMessageDialog(null, "Insira somente números", "Erro", 0);
                }

            }
        }
        return null;
    }//fim atualizaMotoPlaca
}//fim da classe
